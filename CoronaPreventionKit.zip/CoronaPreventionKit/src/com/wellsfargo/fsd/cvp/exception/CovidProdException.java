package com.wellsfargo.fsd.cvp.exception;

public class CovidProdException extends Exception {

	public CovidProdException(String errMsg) {
		super(errMsg);
		// TODO Auto-generated constructor stub
	}

}
